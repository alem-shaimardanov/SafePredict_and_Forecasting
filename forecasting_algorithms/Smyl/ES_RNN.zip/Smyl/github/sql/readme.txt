I provide just two example table creation scrits, one for SQL Server and one for mysql. 
The mysql table is limited to output vector 18, so would not be good for hourly runs.
Anyway, starting using the database is a large investment of time, apart from installationm, you also need to create auxiliary tables with MASE, and a lot of queries. 
I do not have time to do all of it here and suspect there will be little interest in ODBC, so this is all what you get :-)
