These example run scripts. They are meant to be run on 6-core computer and assume that the program, 
M41.exe has been started interactively in Visual Studio, so they add 5 processes.
run61.cmd should be run for ES_RNN and ES_RNN_PI, so Monthly and Quarterly series, 
although for Monthly you probably want to use computer with more cores, unless you are fine waiting a week or so :-)
run61_e.cmd is for ES_RNN_E and ES_RNN_E_PI, so all other cases.